
USE pjc_erp;

CREATE TABLE IF NOT EXISTS admissions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 application_no VARCHAR(60) UNIQUE NOT NULL,
 applicant_name VARCHAR(150) NOT NULL,
 email VARCHAR(190), phone VARCHAR(40),
 course VARCHAR(120), previous_school VARCHAR(180),
 status ENUM('Pending','Approved','Rejected','Waitlisted') DEFAULT 'Pending',
 applied_on DATE NOT NULL,
 notes TEXT
);

CREATE TABLE IF NOT EXISTS fee_structures (
 id INT AUTO_INCREMENT PRIMARY KEY,
 course VARCHAR(120) NOT NULL,
 academic_year VARCHAR(30) NOT NULL,
 tuition_fee DECIMAL(10,2) DEFAULT 0,
 exam_fee DECIMAL(10,2) DEFAULT 0,
 library_fee DECIMAL(10,2) DEFAULT 0,
 activity_fee DECIMAL(10,2) DEFAULT 0,
 other_fee DECIMAL(10,2) DEFAULT 0,
 UNIQUE KEY fee_course_year(course,academic_year)
);

CREATE TABLE IF NOT EXISTS fee_installments (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 installment_no INT NOT NULL,
 due_date DATE NOT NULL,
 amount DECIMAL(10,2) NOT NULL,
 status ENUM('Pending','Paid','Overdue') DEFAULT 'Pending',
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS documents (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NULL,
 title VARCHAR(180) NOT NULL,
 file_path VARCHAR(255) NOT NULL,
 uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS payslips (
 id INT AUTO_INCREMENT PRIMARY KEY,
 salary_id INT NOT NULL,
 slip_no VARCHAR(80) UNIQUE NOT NULL,
 generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(salary_id) REFERENCES salaries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS promotion_history (
 id INT AUTO_INCREMENT PRIMARY KEY,
 student_id INT NOT NULL,
 from_year VARCHAR(30),
 to_year VARCHAR(30),
 academic_year VARCHAR(30),
 promoted_on DATE NOT NULL,
 FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS notifications (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 title VARCHAR(180) NOT NULL,
 body TEXT NOT NULL,
 is_read TINYINT(1) DEFAULT 0,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS settings (
 setting_key VARCHAR(80) PRIMARY KEY,
 setting_value TEXT
);

INSERT IGNORE INTO settings(setting_key,setting_value) VALUES
('college_name','Prajnanbodhini Junior College'),
('college_short','PJC'),
('academic_year','2026-27'),
('contact_email','office@pjc.in'),
('contact_phone','+91 00000 00000');

ALTER TABLE assignments ADD COLUMN IF NOT EXISTS attachment_path VARCHAR(255) NULL;
