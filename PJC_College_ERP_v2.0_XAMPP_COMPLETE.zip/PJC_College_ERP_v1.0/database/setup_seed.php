<?php
require_once __DIR__.'/../config/config.php';
$pdo=db();
$accounts=[
 ['System Administrator','admin@pjc.in','Admin@0911','admin'],
 ['Aarav Student','aarav@students.pjc.in','Demo@0911','student'],
 ['Ananya Teacher','ananya@staff.pjc.in','Demo@0911','teacher'],
];
foreach($accounts as $a){
 $st=$pdo->prepare("SELECT id FROM users WHERE email=?");$st->execute([$a[1]]);
 if(!$st->fetch()){
   $pdo->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)")->execute([$a[0],$a[1],password_hash($a[2],PASSWORD_DEFAULT),$a[3]]);
 }
}
$u=$pdo->query("SELECT id FROM users WHERE email='aarav@students.pjc.in'")->fetchColumn();
if($u && !$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn()){
 $pdo->prepare("INSERT INTO students(user_id,name,email,course,year) VALUES(?,?,?,?,?)")->execute([$u,'Aarav Student','aarav@students.pjc.in','Science','XI']);
}
$u=$pdo->query("SELECT id FROM users WHERE email='ananya@staff.pjc.in'")->fetchColumn();
if($u && !$pdo->query("SELECT COUNT(*) FROM teachers")->fetchColumn()){
 $pdo->prepare("INSERT INTO teachers(user_id,name,email,department,designation) VALUES(?,?,?,?,?)")->execute([$u,'Ananya Teacher','ananya@staff.pjc.in','Science','Senior Teacher']);
}
echo "Seed complete. You can now login at auth/login.php\n";
?>