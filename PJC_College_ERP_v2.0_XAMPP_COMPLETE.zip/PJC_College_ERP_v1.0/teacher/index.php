<?php
require_role('teacher'); $title='Teacher Portal'; require '../includes/header.php';
?>
<main class="container">
<div class="section-title"><div><div class="kicker">Teacher Portal</div><h1>Welcome, <?=e(current_user()['name'])?></h1></div></div>
<div class="navgrid"><a href="index.php">Dashboard</a><a href="students.php">Students</a><a href="attendance.php">Attendance</a><a href="marks.php">Marks</a><a href="assignments.php">Assignments</a><a href="salary.php">Salary</a></div>
<div class="grid grid-4"><div class="card"><div class="muted">My Students</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM students')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Attendance Records</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM attendance')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Marks Records</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM marks')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Assignments</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM assignments')->fetchColumn(); ?></div></div></div>
<div class="card" style="margin-top:18px"><h3>Quick access</h3><p class="muted">Use the navigation above to manage your ERP modules.</p></div>
</main><?php require '../includes/footer.php'; ?>