<?php require_role('admin'); $title='ID Cards'; require '../includes/header.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=(int)$_POST['student_id']; $no='PJC-ID-'.date('Y').'-'.str_pad((string)$s,5,'0',STR_PAD_LEFT);
 db()->prepare("INSERT INTO student_id_cards(student_id,card_no,issued_on,valid_until) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE valid_until=VALUES(valid_until)")
 ->execute([$s,$no,date('Y-m-d'),$_POST['valid_until']]);flash('success','ID card record saved.');redirect('id_cards.php');
}
$students=db()->query("SELECT id,name,course,year FROM students ORDER BY name")->fetchAll(); ?>
<main class="container"><h1>Student ID Cards</h1><div class="card"><form method="post"><div class="form-grid"><div class="field"><label>Student</label><select name="student_id"><?php foreach($students as $s):?><option value="<?=$s['id']?>"><?=e($s['name'])?> — <?=e($s['course'])?></option><?php endforeach;?></select></div><div class="field"><label>Valid until</label><input type="date" name="valid_until"></div></div><br><button class="btn">Issue / Update ID Card</button></form></div></main><?php require '../includes/footer.php'; ?>