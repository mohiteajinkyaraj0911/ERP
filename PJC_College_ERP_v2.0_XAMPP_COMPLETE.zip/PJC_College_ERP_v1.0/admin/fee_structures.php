<?php
require_role('admin'); $title='Fee Structures'; require '../includes/header.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 db()->prepare("INSERT INTO fee_structures(course,academic_year,tuition_fee,exam_fee,library_fee,activity_fee,other_fee) VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE tuition_fee=VALUES(tuition_fee),exam_fee=VALUES(exam_fee),library_fee=VALUES(library_fee),activity_fee=VALUES(activity_fee),other_fee=VALUES(other_fee)")
 ->execute([$_POST['course'],$_POST['academic_year'],$_POST['tuition_fee'],$_POST['exam_fee'],$_POST['library_fee'],$_POST['activity_fee'],$_POST['other_fee']]);
 flash('success','Fee structure saved.'); redirect('fee_structures.php');
}
?>
<main class="container"><h1>Fee Structures</h1><div class="card"><form method="post"><div class="form-grid">
<?php foreach(['course','academic_year','tuition_fee','exam_fee','library_fee','activity_fee','other_fee'] as $f):?><div class="field"><label><?=ucwords(str_replace('_',' ',$f))?></label><input name="<?=$f?>" required></div><?php endforeach;?>
</div><br><button class="btn">Save Structure</button></form></div><br>
<div class="card table-wrap"><table class="table"><tr><th>Course</th><th>Year</th><th>Tuition</th><th>Exam</th><th>Library</th><th>Activity</th><th>Other</th></tr>
<?php foreach(db()->query("SELECT * FROM fee_structures ORDER BY course") as $f):?><tr><td><?=e($f['course'])?></td><td><?=e($f['academic_year'])?></td><td>₹<?=number_format($f['tuition_fee'],2)?></td><td>₹<?=number_format($f['exam_fee'],2)?></td><td>₹<?=number_format($f['library_fee'],2)?></td><td>₹<?=number_format($f['activity_fee'],2)?></td><td>₹<?=number_format($f['other_fee'],2)?></td></tr><?php endforeach;?>
</table></div></main><?php require '../includes/footer.php'; ?>