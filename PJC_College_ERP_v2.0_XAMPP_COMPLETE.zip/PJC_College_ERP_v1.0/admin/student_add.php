<?php require_role('admin'); $title='Add Student'; require '../includes/header.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $name=trim($_POST['name']);$email=trim($_POST['email']);$course=trim($_POST['course']);$year=trim($_POST['year']);$password=$_POST['password'];
 $pdo=db();$pdo->beginTransaction();
 $pdo->prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'student')")->execute([$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
 $uid=(int)$pdo->lastInsertId();$pdo->prepare("INSERT INTO students(user_id,name,email,course,year) VALUES(?,?,?,?,?)")->execute([$uid,$name,$email,$course,$year]);
 $pdo->commit();flash('success','Student created.');redirect('students.php');
} ?>
<main class="container"><div class="card"><h1>Add Student</h1><form method="post"><div class="form-grid">
<div class="field"><label>Name</label><input name="name" required></div><div class="field"><label>Login ID / Email</label><input name="email" required></div>
<div class="field"><label>Course</label><input name="course" required></div><div class="field"><label>Year</label><input name="year" required></div>
<div class="field"><label>Temporary Password</label><input type="password" name="password" required></div></div><br><button class="btn">Create Student</button></form></div></main><?php require '../includes/footer.php'; ?>