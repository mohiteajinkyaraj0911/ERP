<?php
require_role('admin'); $title='Advanced ERP'; require '../includes/header.php';
$stats=[
 ['Admissions','SELECT COUNT(*) FROM admissions'],
 ['Pending Fees','SELECT COUNT(*) FROM fee_installments WHERE status="Pending"'],
 ['Documents','SELECT COUNT(*) FROM documents'],
 ['Notifications','SELECT COUNT(*) FROM notifications']
];
?>
<main class="container">
<div class="section-title"><div><div class="kicker">Advanced administration</div><h1>ERP Control Centre</h1></div></div>
<div class="grid grid-4"><?php foreach($stats as [$label,$q]):?><div class="card"><div class="muted"><?=e($label)?></div><div class="stat"><?= (int)db()->query($q)->fetchColumn() ?></div></div><?php endforeach;?></div>
<br>
<div class="grid grid-3">
<?php foreach([
 ['Admissions','admissions.php','Manage applications and approval status.'],
 ['Fee Structures','fee_structures.php','Configure course-wise fee structures.'],
 ['Installments','installments.php','Create and track student installments.'],
 ['Promotion','promotion.php','Promote students between academic years.'],
 ['Documents','documents.php','Track student document uploads.'],
 ['Reports','../reports/dashboard.php','View management reports.']
] as $m):?><div class="card role-card"><h3><?=e($m[0])?></h3><p class="muted"><?=e($m[2])?></p><a class="btn ghost" href="<?=e($m[1])?>">Open module</a></div><?php endforeach;?>
</div></main><?php require '../includes/footer.php'; ?>