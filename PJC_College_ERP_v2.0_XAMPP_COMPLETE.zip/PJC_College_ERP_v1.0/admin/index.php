<?php
require_role('admin'); $title='Administration Portal'; require '../includes/header.php';
?>
<main class="container">
<div class="section-title"><div><div class="kicker">Administration Portal</div><h1>Welcome, <?=e(current_user()['name'])?></h1></div></div>
<div class="navgrid"><a href="index.php">Dashboard</a><a href="students.php">Students</a><a href="teachers.php">Teachers</a><a href="fees.php">Fees</a><a href="payroll.php">Payroll</a><a href="notices.php">Notices</a><a href="enquiries.php">Enquiries</a></div>
<div class="grid grid-4"><div class="card"><div class="muted">Students</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM students')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Teachers</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM teachers')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Fee Payments</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM fee_payments')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Enquiries</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM visitor_enquiries')->fetchColumn(); ?></div></div></div>
<div class="card" style="margin-top:18px"><h3>Quick access</h3><p class="muted">Use the navigation above to manage your ERP modules.</p></div>
</main><?php require '../includes/footer.php'; ?>