<?php
require_role('admin'); $title='Admissions'; require '../includes/header.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $no='PJC-ADM-'.date('YmdHis').rand(10,99);
 db()->prepare("INSERT INTO admissions(application_no,applicant_name,email,phone,course,previous_school,status,applied_on,notes) VALUES(?,?,?,?,?,?,?,CURDATE(),?)")
 ->execute([$no,$_POST['applicant_name'],$_POST['email'],$_POST['phone'],$_POST['course'],$_POST['previous_school'],'Pending',$_POST['notes']]);
 flash('success','Admission application created.'); redirect('admissions.php');
}
?>
<main class="container"><h1>Admissions</h1>
<div class="card"><form method="post"><div class="form-grid">
<div class="field"><label>Applicant name</label><input name="applicant_name" required></div>
<div class="field"><label>Email</label><input type="email" name="email"></div>
<div class="field"><label>Phone</label><input name="phone"></div>
<div class="field"><label>Course</label><input name="course"></div>
<div class="field"><label>Previous school</label><input name="previous_school"></div>
<div class="field"><label>Notes</label><input name="notes"></div></div><br><button class="btn">Create Application</button></form></div><br>
<div class="card table-wrap"><table class="table"><tr><th>Application</th><th>Name</th><th>Course</th><th>Status</th><th>Date</th></tr>
<?php foreach(db()->query("SELECT * FROM admissions ORDER BY id DESC") as $a):?><tr><td><?=e($a['application_no'])?></td><td><?=e($a['applicant_name'])?></td><td><?=e($a['course'])?></td><td><?=e($a['status'])?></td><td><?=e($a['applied_on'])?></td></tr><?php endforeach;?>
</table></div></main><?php require '../includes/footer.php'; ?>