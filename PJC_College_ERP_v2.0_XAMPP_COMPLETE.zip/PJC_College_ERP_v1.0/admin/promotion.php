<?php
require_role('admin'); $title='Student Promotion'; require '../includes/header.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $s=db()->prepare("SELECT * FROM students WHERE id=?");$s->execute([(int)$_POST['student_id']]);$s=$s->fetch();
 if($s){
  db()->prepare("INSERT INTO promotion_history(student_id,from_year,to_year,academic_year,promoted_on) VALUES(?,?,?,?,CURDATE())")->execute([$s['id'],$s['year'],$_POST['to_year'],$_POST['academic_year']]);
  db()->prepare("UPDATE students SET year=? WHERE id=?")->execute([$_POST['to_year'],$s['id']]);
  flash('success','Student promoted.'); redirect('promotion.php');
 }
}
$students=db()->query("SELECT id,name,year FROM students ORDER BY name")->fetchAll();
?>
<main class="container"><h1>Promotion</h1><div class="card"><form method="post"><div class="form-grid">
<div class="field"><label>Student</label><select name="student_id"><?php foreach($students as $s):?><option value="<?=$s['id']?>"><?=e($s['name'])?> — <?=e($s['year'])?></option><?php endforeach;?></select></div>
<div class="field"><label>New year</label><input name="to_year" placeholder="XII" required></div>
<div class="field"><label>Academic year</label><input name="academic_year" value="2026-27" required></div></div><br><button class="btn">Promote</button></form></div></main><?php require '../includes/footer.php'; ?>