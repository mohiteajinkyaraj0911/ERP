<?php
require_role('admin'); $title='ERP v2.0 Control Centre'; require '../includes/header.php';
$cards=[
 ['🏷️','Departments & Divisions','departments.php'],['🪪','ID Cards','id_cards.php'],['💳','Scholarships','scholarships.php'],
 ['💸','Expenses','expenses.php'],['📝','Leave Requests','leave_requests.php'],['🔄','Transfers / TC','transfers.php'],
 ['📋','Audit Logs','audit.php'],['📅','Events','events.php'],['📈','Analytics','../reports/analytics.php']
]; ?>
<main class="container"><div class="kicker">PJC ERP v2.0</div><h1>Enterprise Control Centre</h1>
<p class="muted">Centralized administration, finance, academics, documents and operational controls.</p>
<div class="grid grid-3"><?php foreach($cards as $c):?><div class="card role-card"><div class="feature-icon"><?=$c[0]?></div><h3><?=e($c[1])?></h3><a class="btn ghost" href="<?=e($c[2])?>">Open</a></div><?php endforeach;?></div>
</main><?php require '../includes/footer.php'; ?>