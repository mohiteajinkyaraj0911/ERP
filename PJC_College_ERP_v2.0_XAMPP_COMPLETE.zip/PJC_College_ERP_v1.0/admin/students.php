<?php require_role('admin'); $title='Student Management'; require '../includes/header.php'; ?>
<main class="container"><div class="section-title"><h1>Students</h1><a class="btn" href="student_add.php">Add Student</a></div>
<div class="card table-wrap"><table class="table"><tr><th>Name</th><th>Login ID</th><th>Course</th><th>Year</th><th>Status</th></tr>
<?php foreach(db()->query("SELECT * FROM students ORDER BY id DESC") as $s): ?><tr><td><?=e($s['name'])?></td><td><?=e($s['email'])?></td><td><?=e($s['course'])?></td><td><?=e($s['year'])?></td><td><?=e($s['status'])?></td></tr><?php endforeach; ?>
</table></div></main><?php require '../includes/footer.php'; ?>