<?php
require_role('admin'); $title='Fee Installments'; require '../includes/header.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
 db()->prepare("INSERT INTO fee_installments(student_id,installment_no,due_date,amount,status) VALUES(?,?,?,?,?)")->execute([(int)$_POST['student_id'],$_POST['installment_no'],$_POST['due_date'],$_POST['amount'],'Pending']);
 flash('success','Installment created.'); redirect('installments.php');
}
$students=db()->query("SELECT id,name FROM students ORDER BY name")->fetchAll();
?>
<main class="container"><h1>Fee Installments</h1><div class="card"><form method="post"><div class="form-grid">
<div class="field"><label>Student</label><select name="student_id"><?php foreach($students as $s):?><option value="<?=$s['id']?>"><?=e($s['name'])?></option><?php endforeach;?></select></div>
<div class="field"><label>Installment no.</label><input type="number" name="installment_no" required></div>
<div class="field"><label>Due date</label><input type="date" name="due_date" required></div>
<div class="field"><label>Amount</label><input type="number" step=".01" name="amount" required></div>
</div><br><button class="btn">Create Installment</button></form></div><br>
<div class="card table-wrap"><table class="table"><tr><th>Student</th><th>#</th><th>Due</th><th>Amount</th><th>Status</th></tr>
<?php foreach(db()->query("SELECT f.*,s.name FROM fee_installments f JOIN students s ON s.id=f.student_id ORDER BY f.due_date") as $x):?><tr><td><?=e($x['name'])?></td><td><?=e($x['installment_no'])?></td><td><?=e($x['due_date'])?></td><td>₹<?=number_format($x['amount'],2)?></td><td><?=e($x['status'])?></td></tr><?php endforeach;?>
</table></div></main><?php require '../includes/footer.php'; ?>