document.querySelectorAll('[data-confirm]').forEach(el=>{
  el.addEventListener('click',e=>{if(!confirm(el.dataset.confirm))e.preventDefault()})
});
setTimeout(()=>document.querySelectorAll('.flash').forEach(x=>x.remove()),5000);