PJC COLLEGE ERP v2.0 — ADVANCED XAMPP EDITION
==============================================

STACK
PHP 8+, MySQL/MariaDB, Apache (XAMPP), HTML5/CSS3/JavaScript.

SETUP
1. Put PJC_College_ERP_v1.0 into C:\xampp\htdocs\
2. Start Apache + MySQL in XAMPP.
3. Open phpMyAdmin.
4. Import database/pjc_erp.sql into MySQL.
5. Import database/advanced_v1_1.sql.
6. Import database/v2_upgrade.sql.
7. Visit database/setup_seed.php once:
   http://localhost/PJC_College_ERP_v1.0/database/setup_seed.php
8. Open:
   http://localhost/PJC_College_ERP_v1.0/

DEMO
Admin:   admin@pjc.in / Admin@0911
Student: aarav@students.pjc.in / Demo@0911
Teacher: ananya@staff.pjc.in / Demo@0911

V2 FEATURES
- Enterprise control centre
- Departments
- ID card records
- Scholarships
- Expense management
- Leave approval
- Transfers / TC / withdrawal records
- Audit logs
- Events
- Live management analytics
- Financial and attendance snapshots
- Existing student/teacher/admin/visitor portals
- Fee installments, structures and printable receipts
- Admission workflow
- Payroll tables
- Promotion history
- Notifications/settings tables

SECURITY NOTE
For real deployment, change demo passwords and add HTTPS, CSRF protection,
strict upload validation, database backups, mail/SMS provider configuration,
environment variables for DB credentials and production access controls.
