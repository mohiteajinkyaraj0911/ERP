<?php
require_role('admin');
$id=(int)($_GET['id']??0);
$st=db()->prepare("SELECT f.*,s.name,s.email,s.course FROM fee_payments f JOIN students s ON s.id=f.student_id WHERE f.id=?");$st->execute([$id]);$p=$st->fetch();
if(!$p){flash('error','Receipt not found.');redirect('../admin/fees.php');}
$title='Fee Receipt'; require '../includes/header.php';
?>
<main class="container"><div class="card" id="receipt"><div class="kicker">Official Fee Receipt</div><h1>Prajnanbodhini Junior College</h1><hr>
<p><b>Receipt No:</b> <?=e($p['receipt_no'])?></p><p><b>Student:</b> <?=e($p['name'])?></p><p><b>Course:</b> <?=e($p['course'])?></p><p><b>Amount:</b> ₹<?=number_format($p['amount'],2)?></p><p><b>Payment method:</b> <?=e($p['method'])?></p><p><b>Date:</b> <?=e($p['paid_on'])?></p>
<br><button class="btn" onclick="window.print()">Print Receipt</button></div></main><?php require '../includes/footer.php'; ?>