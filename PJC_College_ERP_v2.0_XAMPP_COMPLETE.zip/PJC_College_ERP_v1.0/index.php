<?php $title='Prajnanbodhini Junior College'; require 'includes/header.php'; ?>
<main class="container">
<section class="hero">
  <div class="kicker">Prajnanbodhini Junior College · ERP v1.0</div>
  <h1>One intelligent campus.<br>One connected ERP.</h1>
  <p>A modern college management platform for students, teachers, administrators and visitors — with academics, attendance, results, fees, payroll, notices and enquiries in one place.</p>
  <div class="navgrid">
    <a class="btn" href="auth/login.php">ERP Login</a>
    <a class="btn ghost" href="visitor/index.php">Explore College</a>
  </div>
</section>
<section class="grid grid-4">
<?php foreach([
 ['🎓','Student Portal','Attendance, results, timetable, assignments and fees.'],
 ['👨‍🏫','Teacher Portal','Classes, attendance, marks, assignments and salary.'],
 ['⚙️','Admin Portal','Students, staff, fees, payroll, reports and settings.'],
 ['🏫','Visitor Website','College information and admission enquiries.']
] as $x): ?><div class="card role-card"><div class="feature-icon"><?= $x[0] ?></div><h3><?= $x[1] ?></h3><p class="muted"><?= $x[2] ?></p></div><?php endforeach; ?>
</section>
</main><?php require 'includes/footer.php'; ?>