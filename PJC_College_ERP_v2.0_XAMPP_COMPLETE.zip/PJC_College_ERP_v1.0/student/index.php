<?php
require_role('student'); $title='Student Portal'; require '../includes/header.php';
?>
<main class="container">
<div class="section-title"><div><div class="kicker">Student Portal</div><h1>Welcome, <?=e(current_user()['name'])?></h1></div></div>
<div class="navgrid"><a href="index.php">Dashboard</a><a href="profile.php">Profile</a><a href="attendance.php">Attendance</a><a href="results.php">Results</a><a href="fees.php">Fees</a><a href="timetable.php">Timetable</a><a href="notices.php">Notices</a><a href="assignments.php">Assignments</a></div>
<div class="grid grid-4"><div class="card"><div class="muted">Attendance Entries</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM attendance')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Results</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM marks')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Fee Payments</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM fee_payments')->fetchColumn(); ?></div></div><div class="card"><div class="muted">Notices</div><div class="stat"><?php echo (int)db()->query('SELECT COUNT(*) FROM notices')->fetchColumn(); ?></div></div></div>
<div class="card" style="margin-top:18px"><h3>Quick access</h3><p class="muted">Use the navigation above to manage your ERP modules.</p></div>
</main><?php require '../includes/footer.php'; ?>