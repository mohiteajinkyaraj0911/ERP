<?php
declare(strict_types=1);
session_start();

const DB_HOST = '127.0.0.1';
const DB_NAME = 'pjc_erp';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            'mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',
            DB_USER, DB_PASS,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
             PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]
        );
    }
    return $pdo;
}

function e(?string $value): string { return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8'); }
function redirect(string $url): never { header("Location: $url"); exit; }
function flash(string $type, string $message): void { $_SESSION['flash'] = [$type, $message]; }
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        [$type,$message] = $_SESSION['flash'];
        echo '<div class="flash '.e($type).'">'.e($message).'</div>';
        unset($_SESSION['flash']);
    }
}
function require_role(string $role): void {
    if (empty($_SESSION['user']) || $_SESSION['user']['role'] !== $role) redirect('/PJC_College_ERP_v1.0/auth/login.php');
}
function current_user(): array { return $_SESSION['user'] ?? []; }
?>