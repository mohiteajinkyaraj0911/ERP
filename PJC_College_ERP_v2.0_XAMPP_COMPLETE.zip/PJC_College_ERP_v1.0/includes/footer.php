<footer class="footer">© <?= date('Y') ?> Prajnanbodhini Junior College · ERP v1.0</footer>
<script src="/PJC_College_ERP_v1.0/assets/js/app.js"></script>
</body></html>