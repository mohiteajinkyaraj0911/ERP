<?php require_once __DIR__.'/../config/config.php'; ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'PJC ERP') ?></title>
<link rel="stylesheet" href="/PJC_College_ERP_v1.0/assets/css/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="/PJC_College_ERP_v1.0/index.php"><span class="brand-mark">P</span><span>Prajnanbodhini<br><small>Junior College ERP</small></span></a>
  <div class="top-actions">
    <?php if (!empty($_SESSION['user'])): ?>
      <span class="user-chip"><?= e($_SESSION['user']['name']) ?> · <?= e(ucfirst($_SESSION['user']['role'])) ?></span>
      <a class="btn ghost" href="/PJC_College_ERP_v1.0/auth/logout.php">Logout</a>
    <?php endif; ?>
  </div>
</header>
<?php show_flash(); ?>