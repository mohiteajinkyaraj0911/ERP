<?php
require_once __DIR__.'/../config/config.php';
function audit(string $action,string $module='system'): void {
 try { db()->prepare("INSERT INTO audit_logs(user_id,action,module,ip_address) VALUES(?,?,?,?)")
   ->execute([$_SESSION['user']['id']??null,$action,$module,$_SERVER['REMOTE_ADDR']??'unknown']); } catch(Throwable $e) {}
}
?>