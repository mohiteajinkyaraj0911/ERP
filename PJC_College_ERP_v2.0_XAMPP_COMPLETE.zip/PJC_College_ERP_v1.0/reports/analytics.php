<?php require_role('admin'); $title='Analytics'; require '../includes/header.php';
$fee=(float)db()->query("SELECT COALESCE(SUM(amount),0) FROM fee_payments")->fetchColumn();
$exp=(float)db()->query("SELECT COALESCE(SUM(amount),0) FROM expenses")->fetchColumn();
$sal=(float)db()->query("SELECT COALESCE(SUM(amount),0) FROM salaries")->fetchColumn();
$students=(int)db()->query("SELECT COUNT(*) FROM students")->fetchColumn();
$present=(int)db()->query("SELECT COUNT(*) FROM attendance WHERE status='Present'")->fetchColumn();
$totalatt=(int)db()->query("SELECT COUNT(*) FROM attendance")->fetchColumn();
$pct=$totalatt?round($present/$totalatt*100,1):0;
?>
<main class="container"><div class="kicker">Live database analytics</div><h1>Management Analytics</h1>
<div class="grid grid-4"><div class="card"><div class="muted">Students</div><div class="stat"><?=$students?></div></div><div class="card"><div class="muted">Attendance</div><div class="stat"><?=$pct?>%</div></div><div class="card"><div class="muted">Fees</div><div class="stat">₹<?=number_format($fee,0)?></div></div><div class="card"><div class="muted">Expenses</div><div class="stat">₹<?=number_format($exp,0)?></div></div></div><br>
<div class="grid grid-2"><div class="card"><h3>Financial snapshot</h3><p>Fees collected: <b>₹<?=number_format($fee,2)?></b></p><p>Payroll processed: <b>₹<?=number_format($sal,2)?></b></p><p>Operating expenses: <b>₹<?=number_format($exp,2)?></b></p></div><div class="card"><h3>Academic snapshot</h3><p>Total attendance records: <b><?=$totalatt?></b></p><p>Present records: <b><?=$present?></b></p><p>Calculated attendance: <b><?=$pct?>%</b></p></div></div></main><?php require '../includes/footer.php'; ?>