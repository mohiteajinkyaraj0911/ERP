<?php
require_role('admin'); $title='Reports'; require '../includes/header.php';
$students=(int)db()->query("SELECT COUNT(*) FROM students")->fetchColumn();
$teachers=(int)db()->query("SELECT COUNT(*) FROM teachers")->fetchColumn();
$payments=(float)db()->query("SELECT COALESCE(SUM(amount),0) FROM fee_payments")->fetchColumn();
$salary=(float)db()->query("SELECT COALESCE(SUM(amount),0) FROM salaries")->fetchColumn();
?>
<main class="container"><div class="kicker">Management intelligence</div><h1>Reports Dashboard</h1>
<div class="grid grid-4"><div class="card"><div class="muted">Students</div><div class="stat"><?=$students?></div></div><div class="card"><div class="muted">Teachers</div><div class="stat"><?=$teachers?></div></div><div class="card"><div class="muted">Fees collected</div><div class="stat">₹<?=number_format($payments,2)?></div></div><div class="card"><div class="muted">Salary processed</div><div class="stat">₹<?=number_format($salary,2)?></div></div></div>
<br><div class="card"><h3>Financial summary</h3><p class="muted">Fee collections and salary totals are calculated directly from MySQL records.</p></div>
</main><?php require '../includes/footer.php'; ?>