<?php
$title='ERP Login'; require '../includes/header.php';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $email=trim($_POST['email']??''); $password=$_POST['password']??'';
    $st=db()->prepare("SELECT * FROM users WHERE email=? AND status='active' LIMIT 1"); $st->execute([$email]); $u=$st->fetch();
    if ($u && password_verify($password,$u['password_hash'])) {
        $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']];
        try { db()->prepare("INSERT INTO audit_logs(user_id,action,module,ip_address) VALUES(?,?,?,?)")->execute([$u['id'],'Successful login','authentication',$_SERVER['REMOTE_ADDR']??'unknown']); } catch(Throwable $e) {}
        if($u['role']==='admin') redirect('../admin/index.php');
        if($u['role']==='teacher') redirect('../teacher/index.php');
        redirect('../student/index.php');
    }
    flash('error','Invalid login credentials.'); redirect('login.php');
}
?>
<main class="login-page"><div class="card login-card">
<div class="kicker">Secure access</div><h1>ERP Login</h1><p class="muted">Use your college account to continue.</p>
<form method="post"><div class="field"><label>Email / Login ID</label><input name="email" required></div><br><div class="field"><label>Password</label><input type="password" name="password" required></div><br><button class="btn">Sign in</button></form>
<hr><p class="muted">Demo admin: admin@pjc.in · Password: Admin@0911</p>
</div></main><?php require '../includes/footer.php'; ?>